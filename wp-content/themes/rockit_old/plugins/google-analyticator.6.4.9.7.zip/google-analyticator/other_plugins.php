 <?php add_thickbox(); ?>
 <div class="wrap">
	<?php screen_icon(); ?>
	<h2>Other Plugins</h2>
	
        <p style="border:1px solid #CCCCCC;background:#FFFFFF;padding:8px;">
                <a href="<?php echo admin_url( 'plugin-install.php?tab=plugin-information&plugin=sumome&TB_iframe=true&width=743&height=500'); ?>" class="thickbox">SumoMe</a> - Tools to grow your Email List, Social Sharing and Analytics.
                <br /><br />
                <a href="<?php echo admin_url('plugin-install.php?tab=plugin-information&plugin=recent-tweets-widget&TB_iframe=true&width=743&height=500'); ?>" class="thickbox">Recent Tweets Widget</a> - Display your recent tweets in a sidebar widget.
                <br /><br />
                <a href="<?php echo admin_url('plugin-install.php?tab=plugin-information&plugin=social-share-boost&TB_iframe=true&width=743&height=500'); ?>" class="thickbox">Social Share Boost</a> - Boost Your Social Sharing by automatically adding various social share tools above or below the posts, page and excerpts.
        </p>
        <h2>Signup for a free 30 day course to DOUBLE YOUR EMAIL LIST</h2>
        <div style="border:1px solid #CCCCCC;background:#FFFFFF;padding:8px;">
                <form method="post" class="af-form-wrapper" action="http://www.aweber.com/scripts/addlead.pl" target="_blank">
                        <p>
                                <input placeholder="Type Your Email Address" class="email" name="email" autofocus style="width:200px;" />
                        </p>
                        <p>
                                <button class="button button-primary">Let me in!</button>
                        </p>

                        <input type="hidden" name="meta_web_form_id" value="1747290999" />
                        <input type="hidden" name="meta_split_id" value="" />
                        <input type="hidden" name="listname" value="awlist3626406" />
                        <input type="hidden" name="redirect" value="http://email1k.sumome.com/tweet.html" id="redirect_19605a373ab8e7f77fc954424326ab1c" />
                        <input type="hidden" name="meta_redirect_onlist" value="http://email1k.sumome.com/tweet.html" />
                        <input type="hidden" name="meta_adtracking" value="google-analyticator" />
                        <input type="hidden" name="meta_message" value="1" />
                        <input type="hidden" name="meta_required" value="email" />
                        <input type="hidden" name="meta_tooltip" value="" />
                </form>
        </div>
</div>